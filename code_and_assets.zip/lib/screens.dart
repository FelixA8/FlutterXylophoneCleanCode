import 'package:flutter/material.dart';
import 'package:my_app/widgets/piano.dart';

class Screen extends StatelessWidget {
  const Screen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Piano(number: 1, col: Colors.red),
            ),
            Expanded(
              child: Piano(number: 2, col: Colors.orange),
            ),
            Expanded(
              child: Piano(number: 3, col: Colors.yellow),
            ),
            Expanded(
              child: Piano(number: 4, col: Colors.green),
            ),
            Expanded(
              child: Piano(number: 5, col: Colors.blue),
            ),
            Expanded(
              child: Piano(number: 6, col: Colors.grey),
            ),
            Expanded(
              child: Piano(number: 7, col: Colors.purple),
            ),
          ],
        ),
      ),
    );
  }
}
