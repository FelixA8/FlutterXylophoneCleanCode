import 'package:flutter/material.dart';
import 'package:my_app/screens.dart';

void main() {
  runApp(
    const MaterialApp(
      home: Screen(),
    ),
  );
}
