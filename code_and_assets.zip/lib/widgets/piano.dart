import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class Piano extends StatefulWidget {
  const Piano({super.key, required this.number, required this.col});
  // ignore: prefer_typing_uninitialized_variables
  final number;
  final Color col;

  @override
  State<Piano> createState() => _PianoState();
}

class _PianoState extends State<Piano> {
  Future _play() async {
    final player = AudioPlayer();
    await player.play(AssetSource('note${widget.number}.wav'));
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _play,
      child: Container(
        color: widget.col,
        child: const Center(
          child: Icon(
            Icons.music_note,
            size: 90,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
